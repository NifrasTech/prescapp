Dear {{$user->name}},

Quotation Created for your prescription..

Total amount is: {{$total}}