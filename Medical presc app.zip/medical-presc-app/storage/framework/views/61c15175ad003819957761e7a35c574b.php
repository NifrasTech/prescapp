

<?php $__env->startSection('content'); ?>

<?php
    $is_pharmacy = false;
    if(auth()->user()->type == 'pharmacy'){
        $is_pharmacy = true;
    }
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">View Prescription</div>

                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>User</th>
                                <th>Address</th>
                                <th>Delivery Time</th>
                                <th>Note</th>
                                <?php if($is_pharmacy): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($prescription->created_at); ?></td>
                                <td><?php echo e($prescription->user->name); ?></td>
                                <td><?php echo e($prescription->address); ?></td>
                                <td><?php echo e(date('g:i A', strtotime($prescription->delivery_time ))); ?></td>
                                <td><?php echo e($prescription->note); ?></td>
                                <?php if($is_pharmacy): ?>
                                <td><a href="/create/<?php echo e($prescription->id); ?>/quotation/">Quotation</a></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\medical-presc-app\resources\views/view-prescriptions.blade.php ENDPATH**/ ?>