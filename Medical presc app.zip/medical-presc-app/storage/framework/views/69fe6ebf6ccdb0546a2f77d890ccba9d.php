

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">View Quotation</div>

                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Prescription #</th>
                                <th>User</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($quotation->created_at); ?></td>
                                <td><?php echo e(str_pad($quotation->prescription_id, 4, '0', STR_PAD_LEFT)); ?></td>
                                <td><?php echo e($quotation->user->name); ?></td>
                                <td><?php echo e($quotation->total); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <a class="btn btn-secondary dropdown-toggle" id="status_<?php echo e($quotation->id); ?>"
                                            href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <?php echo e(ucfirst($quotation->status)); ?>

                                        </a>

                                        <ul class="dropdown-menu">
                                            <?php if(auth()->user()->type=='user'): ?>
                                            <li><a class="dropdown-item" data-id="<?php echo e($quotation->id); ?>"
                                                    data-status="accepted" href="#">Accepted</a></li>
                                            <li><a class="dropdown-item" data-id="<?php echo e($quotation->id); ?>"
                                                    data-status="rejected" href="#">Rejected</a></li>
                                            <?php else: ?>
                                            <li><a class="dropdown-item" data-id="<?php echo e($quotation->id); ?>"
                                                    data-status="pending" href="#">Pending</a></li>
                                            <li><a class="dropdown-item" data-id="<?php echo e($quotation->id); ?>"
                                                    data-status="delivered" href="#">Delivered</a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                                <td><button onclick="viewQuotationItem(<?php echo e($quotation->id); ?>)"
                                        class="btn btn-sm btn-info">View</button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('components.quotation-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    $('.dropdown-item').on('click', function(event) {
        event.preventDefault();
        // Get the status and ID data attributes from the dropdown item
        let status = $(this).data('status');
        let id = $(this).data('id');
        // Make a POST request to the server to update the quotation status

        $(`#status_${id}`).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...')

        $.post('/quotation/status', {
                id: id,
                status: status,
                _token: '<?php echo e(csrf_token()); ?>'
            })
            .done(function(response) {
                // Display an alert to the user indicating the status update was successful
                alert('Status updated as ' + status);
                // Update the quotation status displayed on the page
                $(`#status_${id}`).html(status.charAt(0).toUpperCase() + status.slice(1));
            })
            .fail(function(xhr, status, error) {
                console.log(error);
            });
    });
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\medical-presc-app\resources\views/view-quotations.blade.php ENDPATH**/ ?>