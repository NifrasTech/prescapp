<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Notification')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-info alert-dismissible fade show" role="alert">
                        The Quotation: <strong><a href="#" onclick="viewQuotationItem(<?php echo e($notification->data['quotation_id']); ?>)"><?php echo e(str_pad($notification->data['quotation_id'], 4, '0', STR_PAD_LEFT)); ?> </a> </strong> is
                        <?php echo e($notification->data['quotation_status']); ?> 
                        <?php if(auth()->user()->type == 'pharmacy'): ?>
                        by User: <?php echo e($notification->data['user']['name']); ?>

                        <?php endif; ?>
                        <button type="button" class="btn-close" data-id="<?php echo e($notification->id); ?>" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('components.quotation-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$('.btn-close').on('click', function() {
    let id = $(this).data('id');
    $.post(`/notifications/mark-read`, { _token: '<?php echo e(csrf_token()); ?>', id:id })
        .done(() => {
            // Optionally do something after marking the notification as read
        });
});
</script>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\medical-presc-app\resources\views/home.blade.php ENDPATH**/ ?>