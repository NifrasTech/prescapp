Dear <?php echo e($user->name); ?>,

Quotation Created for your prescription..

Total amount is: <?php echo e($total); ?><?php /**PATH D:\Projects\medical-presc-app\resources\views/mail/notify-user.blade.php ENDPATH**/ ?>