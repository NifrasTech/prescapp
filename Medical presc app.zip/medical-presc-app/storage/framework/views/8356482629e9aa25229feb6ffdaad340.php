      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Prescriptions</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Quotations</a>
      </li><?php /**PATH D:\Projects\medical-presc-app\resources\views/layouts/admin-sidebar.blade.php ENDPATH**/ ?>